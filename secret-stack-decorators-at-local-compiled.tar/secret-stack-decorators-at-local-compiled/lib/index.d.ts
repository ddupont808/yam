export declare type MuxRpcOutputTypes = 'sync' | 'async' | 'source' | 'sink' | 'duplex';
export declare type MuxRpcPermissions = Record<string, 'allow' | 'deny'>;
export declare function local(): (target: any, methodName: string) => void;
export declare function muxrpc(type: MuxRpcOutputTypes, perms?: MuxRpcPermissions): (target: any, methodName: string) => void;
export declare function plugin(version: string): (constructor: any) => void;
